# Data

The original research train/test datasets are not included in this portfolio package.

Expected original research files:
- `train_timeseries.xlsx`
- `test_timeseries.xlsx`

Target: `R_pressure`  
Curve identifier: `curve_id`  
Temporal order: `t_index`  
Time variable: `Q_time`

Only publish the original datasets if you have explicit permission to do so.

For the Streamlit visualization tab, you can upload a derived prediction CSV with:
`curve_id,Q_time,observed_pressure,predicted_pressure,segment`
