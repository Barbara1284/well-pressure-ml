# Deployment Guide

## Option A — GitHub repository
1. Create a new repository, e.g. `well-pressure-ml`.
2. Upload the contents of this folder.
3. Replace the author/contact placeholders in `README.md` and `index.html`.
4. Do **not** upload raw research data unless you have permission.
5. Add a repository description:
   `Machine learning for predicting unobserved segments of oil-well pressure recovery curves.`

## Option B — GitHub Pages
The included `index.html` is self-contained and uses local images.

1. Push the repository to GitHub.
2. Settings → Pages.
3. Deploy from branch.
4. Select `main` and `/ (root)`.
5. Save.

## Option C — Streamlit
1. Install:
   `pip install -r requirements-demo.txt`
2. Run:
   `streamlit run app.py`
3. For Streamlit Community Cloud, connect the GitHub repository and select `app.py`.

## Before publishing
- Replace name/contact placeholders.
- Confirm you are permitted to publish each figure.
- Keep `train_timeseries.xlsx` and `test_timeseries.xlsx` private unless data-sharing permission is explicit.
- If a paper is under review or unpublished, do not publish sensitive manuscript content without coauthor approval.
