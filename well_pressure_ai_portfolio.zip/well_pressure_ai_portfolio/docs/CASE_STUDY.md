# Portfolio Case Study

## One-line pitch
I developed a machine-learning pipeline to predict the continuation of oil-well pressure recovery curves from partial temporal observations.

## Problem
Incomplete pressure-recovery observations can limit interpretation. The project evaluates whether ML can use the observed portion of each curve and reservoir/operational context to reconstruct the subsequent segment.

## Why this is technically interesting
A random train/test split would leak temporal information and overstate performance. The experiment therefore preserves temporal order and validates on later observations within each training curve.

## Approach
- Feature engineering for temporal evolution
- RF, XGBoost, MLP and TabPFN-3
- Optuna/TPE with 50 trials for RF/XGB/MLP
- Five independent final runs, seeds 42–46
- Global and per-curve evaluation
- Residual analysis across the prediction horizon
- SHAP interpretation and 3D response surfaces

## Best result
XGBoost: RMSE 0.3655 ± 0.0023 MPa; R² 0.9922 ± 0.0001.

## Most important insight
Accuracy is high globally, but prediction becomes harder farther from the observed portion of the curve. This turns the project from a pure benchmark into an engineering decision-support study with a clear operational limitation.

## Explainability
Reservoir pressure was the strongest SHAP variable (~40% relative importance), followed by bottomhole pressure and temporal index.

## Practical impact
The approach can support reconstruction of incomplete tests and early estimation of subsequent pressure behavior. It should complement—not replace—physical measurements and conventional reservoir-engineering interpretation.
