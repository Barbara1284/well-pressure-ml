# Publishing Checklist

- [ ] Replace author/contact placeholders.
- [ ] Add your GitHub profile link.
- [ ] Add your LinkedIn link.
- [ ] Decide whether the repository will be public or private.
- [ ] Confirm data/figure publication permissions with the research team.
- [ ] Do not publish raw train/test files without permission.
- [ ] Add the final paper citation only after the publication details are confirmed.
- [ ] Test `streamlit run app.py`.
- [ ] Open `index.html` locally and check all images.
- [ ] Rename the GitHub repository to a concise English name, e.g. `well-pressure-ml`.
