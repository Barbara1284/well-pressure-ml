# CV and LinkedIn Copy

## CV – compact version
**Machine Learning for Oil-Well Pressure Prediction**  
Developed an end-to-end ML pipeline to predict unobserved segments of oil-well pressure recovery curves using XGBoost, Random Forest, MLP and TabPFN-3. Implemented temporal validation, Optuna/TPE hyperparameter optimization, repeated-seed evaluation and SHAP interpretability. XGBoost achieved R² = 0.9922 and RMSE = 0.3655 MPa on temporally subsequent test observations.

## CV – bullet version
- Built a supervised regression pipeline to reconstruct temporally unobserved segments of oil-well pressure recovery curves.
- Benchmarked Random Forest, XGBoost, MLP and TabPFN-3 using a temporal validation protocol.
- Optimized RF/XGB/MLP with Optuna/TPE (50 trials/model) and evaluated five independent seeds.
- Achieved XGBoost RMSE of 0.3655 ± 0.0023 MPa and R² of 0.9922 ± 0.0001.
- Used SHAP and response surfaces to connect model behavior with reservoir pressure, bottomhole pressure and temporal variables.

## LinkedIn project description
I developed a machine-learning application focused on a reservoir-engineering problem: predicting the continuation of pressure recovery curves when only part of the temporal response is available.

The study compares Random Forest, XGBoost, MLP and TabPFN-3 under a temporal validation protocol designed to avoid random-split leakage. RF, XGBoost and MLP were optimized with Optuna/TPE, and the final comparison used the same five random seeds for all models.

XGBoost achieved the best overall reconstruction performance, with RMSE = 0.3655 ± 0.0023 MPa and R² = 0.9922 ± 0.0001. I also used SHAP to interpret the predictions and analyzed how reconstruction error changes as the prediction moves farther from the observed portion of each curve.

Technologies: Python, Pandas, Scikit-learn, XGBoost, Optuna, SHAP, TabPFN and temporal validation.

## Interview answer – 45 seconds
One of my strongest AI projects was a machine-learning system for predicting the continuation of oil-well pressure recovery curves from partial observations. I compared four approaches—Random Forest, XGBoost, MLP and TabPFN-3—and designed the validation around time rather than using a random split, because the real problem is predicting later pressure points. I optimized the conventional models with Optuna and evaluated all models across five identical random seeds. XGBoost achieved an R² of 0.9922 and RMSE of 0.3655 MPa. Beyond accuracy, I analyzed the error by prediction horizon and used SHAP to verify which reservoir, pressure and temporal variables were driving the predictions.
