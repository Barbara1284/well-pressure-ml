# Source module

The research implementation is preserved in `notebooks/`.

For a production refactor, migrate stable preprocessing, feature engineering, training and inference functions into this directory. The portfolio package intentionally does not invent a serialized production model that was not provided.
